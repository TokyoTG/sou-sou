<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use App\Group;

use App\GroupUser;

class CustomUser extends Model
{
    //

    protected $table = "users";
}
