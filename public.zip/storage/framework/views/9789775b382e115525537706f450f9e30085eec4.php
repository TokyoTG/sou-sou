


<?php echo $__env->make('partials.auth_check', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('title'); ?>
<title>YBA | Flowers </title> 
    <?php if(is_admin()): ?>
       <h4>Flowers</h4>   

    <?php elseif(is_member()): ?>
    <h4>My Flowers</h4>
    
    <?php endif; ?>
  <link rel="stylesheet" href="<?php echo e(asset('dashboard/assets/css/mystyle.css')); ?>">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('newBtn'); ?>
<?php if(is_admin()): ?>
 <button class="d-sm-inline-block btn  btn-primary shadow-sm" data-toggle="modal" data-target="#myModal"> New
     <i class="fa fa-plus my-float"></i></button>
     
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>
<?php if(Session::has('message')): ?>
<p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>">
    <?php echo e(Session::get('message')); ?></p>
<?php endif; ?>
  <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">All Flowers</h6>
            </div>

            <div class="card-body">
              <div >
                <?php if(is_admin()): ?>
                
                <?php if(isset($groups)): ?>
                    <?php if(count($groups) > 0): ?>
                        <table id="bootstrap-data-table" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>No. of Members</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               
                                <tr>
                                <form action="<?php echo e(route('flowers.update',$group->id)); ?>" method="POST" id=<?php echo e("update".$group->id); ?>>
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="group_status" class="input-status">
                                        <input type="hidden" name="group_name" class="input-name">
                                        <input type="hidden" name="request" class="request">
                                        <input name="_method" type="hidden" value="PUT">
                                 </form>
                                 <form action="<?php echo e(route('flowers.destroy',$group->id)); ?>" method="POST" id=<?php echo e("delete".$group->id); ?>>
                                    <?php echo csrf_field(); ?>
                                    <input name="_method" type="hidden" value="DELETE">
                                </form>

                                <form action="<?php echo e(route('flowers.update',$group->id)); ?>" method="POST" id=<?php echo e("split".$group->id); ?>>
                                    <?php echo csrf_field(); ?>
                                    <input name="_method" type="hidden" value="PUT">
                                    <input type="hidden" name="request" class="request">
                                </form>
                                <td><?php echo e(isset($group->name) ? $group->name : "Not Set"); ?></td>
                                <td><?php echo e(count($group['group_users'])); ?></td>
                                <td><?php echo e(isset($group->status) ? $group->status : "Not Set"); ?></td>
                                <td>
                                    <div class="btn-group mt-2 mr-1">
                                        <button type="button" class="btn btn-primary dropdown-toggle"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Actions<i class="icon"><span data-feather="chevron-down"></span></i>
                                        </button>
                                        <div class="dropdown-menu dropdown-menu-right">

                                            
                                            <a class="dropdown-item" href="<?php echo e(route('flowers.show', $group->id)); ?>">View Flower</a>


                                            <a class="dropdown-item"
                                            href="#" data-group_id=<?php echo e($group->id); ?>

                                            data-group_name =<?php echo e($group->name); ?>

                                            data-request = <?php echo e($group->status == 'open' ? 'closed' : "open"); ?>

                                            onclick="showModal(this,'close-group')"
                                            ><?php echo e($group->status == 'open' ? 'Close Flower' : "Open Flower"); ?></a>

                                            <a class="dropdown-item" 
                                            href="#" data-group_id=<?php echo e($group->id); ?>

                                            data-group_name =<?php echo e($group->name); ?>

                                             onclick="showModal(this,'rename-group')"
                                            >Rename</a>


                                            <a class="dropdown-item" 
                                            href="#" data-group_id=<?php echo e($group->id); ?>

                                            data-group_name =<?php echo e($group->name); ?>

                                             onclick="showModal(this,'split-group')"
                                            >Split</a> 
                                             

                                            <a class="dropdown-item" 
                                            href="#" data-group_id=<?php echo e($group->id); ?>

                                            data-group_name =<?php echo e($group->name); ?>

                                             onclick="showModal(this,'delete-group')"
                                            >Delete</a>   
                                            
                                            
                                        </div>
                                     </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        No flowers to display
                    <?php endif; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
                

               <?php elseif(is_member()): ?>
               
               <?php if(isset($groups)): ?>
                   <?php if(count($groups) > 0): ?>
                   <table id="bootstrap-data-table" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Level</th>
                            
                            <th>View Flower</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($group->group->name); ?></td>
                        <td><?php echo e($group->user_level); ?></td>
                        
                        <td > <a href="<?php echo e(route('flowers.show', $group->group_id)); ?>"> View <i class="fa fa-eye"></i> </a> </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                   <?php else: ?>
                       <p>You not in any flower yet, join the waiting list please.</p>
                   <?php endif; ?>
               <?php endif; ?>
               
                     
                
               
               <?php endif; ?>
           </div>
            </div>
</div>

<div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel">Create New Flower</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <form method="POST" action="<?php echo e(route('flowers.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name" class="control-label mb-1">Flower Name</label>
                    <input id="name" name="name" type="text" class="form-control" aria-required="true" aria-invalid="false">
                </div>
                    <div class="form-group">
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary btn-block">Create Flower</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
            </div>

        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>


<div id="delete-group" class="modal fade">
	<div class="modal-dialog modal-confirm modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header flex-column">
				<div class="icon-box">
                    <i class="fa fa-times"></i>
				</div>						
				<h4 class="modal-title w-100">Are you sure?</h4>	
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			</div>
			<div class="modal-body">
				<p>Do you really want to delete <strong class="g-name">GROUP NAME</strong> flower? This process cannot be undone.</p>
			</div>
			<div class="modal-footer justify-content-center">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button  class="btn btn-primary" onclick="deleteGroup()">Proceed</button>
			</div>
		</div>
	</div>
</div>


<div id="split-group" class="modal fade">
	<div class="modal-dialog modal-confirm modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header flex-column">
				<div class="icon-box">
                    <i class="fa fa-times"></i>
				</div>						
				<h4 class="modal-title w-100">Are you sure?</h4>	
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			</div>
			<div class="modal-body">
				<p>Do you really want to split <strong class="g-name">GROUP NAME</strong> flower ? This process cannot be undone.</p>
			</div>
			<div class="modal-footer justify-content-center">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button  class="btn btn-primary" onclick="splitGroup()">Proceed</button>
			</div>
		</div>
	</div>
</div>



<div id="close-group" class="modal fade">
	<div class="modal-dialog modal-confirm modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header flex-column">
				<div class="icon-box">
                    <i class="fa fa-times"></i>
				</div>						
				<h4 class="modal-title w-100">Are you sure?</h4>	
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			</div>
			<div class="modal-body">
				<p>Do you really want to <span id="request-option"></span> <strong class="g-name">GROUP NAME</strong> flower? This process cannot be undone.</p>
			</div>
			<div class="modal-footer justify-content-center">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button  class="btn btn-primary" onclick="updateGroup()">Proceed</button>
			</div>
		</div>
	</div>
</div>

<div id="rename-group" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel">Rename Flower</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="new_name" class="control-label mb-1">Enter New name for <span class="g-name"></span></label>
                    <input id="new_name"  type="text" class="form-control" aria-required="true" aria-invalid="false">
                </div>
                <div class="form-group">
                    <div class="col-12">
                        <button type="button" class="btn btn-primary btn-block"  onclick="renameGroup()">Rename Flower</button>
                    </div>
                </div>
             
            </div>
            <div class="modal-footer">
            </div>
  
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
    <script>
        let group_id;
        let group_name;
        function showModal(element,modalName){
             group_id = element.dataset.group_id;
             group_name = element.dataset.group_name;
            let option = element.dataset.request;
            let request  = element.textContent.split(' ')[0].toLowerCase();
            $('#request-option').text(request);
            $('.g-name').text(group_name);
            $('.input-status').val(option);

            $(`#${modalName}`).modal('show');
        }

        function updateGroup(){
            $('.request').val('status');
            $(`#update${group_id}`).submit();
        }

        function splitGroup(){
            $('.request').val('split');
            $(`#update${group_id}`).submit();
        }

        function renameGroup(){
            $('.request').val('rename');
            let new_name = $("#new_name").val();
            $('.input-name').val(new_name);
            $(`#update${group_id}`).submit();
        }

        function deleteGroup(){
            $(`#delete${group_id}`).submit();
            console.log('hi')
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sou-sou\sou-sou\resources\views/dashboard/groups.blade.php ENDPATH**/ ?>