
<?php $__env->startSection('custom_css'); ?>
    
<?php echo $__env->make('partials.auth_check', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('title'); ?>
<title>YBA | Wait List </title> 
    <h4>Wait List</h4>
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/assets/css/mystyle.css')); ?>">
<?php $__env->stopSection(); ?>

<?php

  $list = $data['list'];
  $groups = $data['groups'];


    function position_prepare($value){
      $str = strval($value);
      
      if(strlen($str) <= 1 ){
        
        if(gettype(strpos($str, '1')) == 'integer'){
          $res = $str."st";
          return $res;
        }
        if(gettype(strpos($str, '2')) == 'integer'){
          $res = $str."nd";
          return $res;
        }
        if(gettype(strpos($str, '3')) == 'integer'){
          $res = $str.'rd';
          return $res;
        }else{
          $res =$str. 'th';
          return $res;
        }
      }
      if(strlen($str) > 1){
        if(gettype(strpos($str, '1',1)) == 'integer'){
          $res = $str."st";
          return $res;
        }
        if (gettype(strpos($str, '2',1)) == 'integer') {
            $res = $str. "nd";
            return $res;
        }

        if ( gettype(strpos($str, '3',1)) == 'integer') {
            $res = $str.'rd';
            return $res;
        }else{
          $res =$str. 'th';
        }
      }
      return $res;
    }
?>


<?php $__env->startSection('newBtn'); ?>
   <?php if(is_admin()): ?>
 <button class="d-sm-inline-block btn  btn-primary shadow-sm" onclick="generateModal()">Generate Flower</button>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>
<?php if(Session::has('message')): ?>
<p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>">
    <?php echo e(Session::get('message')); ?></p>
<?php endif; ?>
  <div class="card shadow mb-4">
            <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Wait List</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <?php if(isset($list)): ?>
                  <?php if(count($list) > 0): ?>
                  <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                      <tr>
                        <th>User Name</th>
                        <th>Position</th>
                        <th>Frequency</th>
                        <th>Date of Request</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($item->user->full_name); ?></td>
                          <td><?php echo e(position_prepare($item->position)); ?></td>
                          <td><?php echo e($item->frequency); ?></td>
                        <td><?php echo e($item->created_at); ?></td>
                        <td>
                            <div class="btn-group mt-2 mr-1">
                              <button type="button" class="btn btn-primary dropdown-toggle"
                                  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  Actions<i class="icon"><span data-feather="chevron-down"></span></i>
                              </button>
                              <div class="dropdown-menu dropdown-menu-right">
                                   <a class="dropdown-item" href="<?php echo e(route('users.show', $item->user_id)); ?>">View User</a>
                                  <a class="dropdown-item" href="#"
                                  data-user_id=<?php echo e($item->id); ?>

                                  onclick="showModal(this,'addUser')"
                                  data-user_name=<?php echo e($item->user->full_name); ?>

                                    
                                  >Add to Flower</a>

                                  
                                  <form action="<?php echo e(route('group_users.store')); ?>" method="post" id=<?php echo e("add".$item->id); ?>>
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="user_level" class="user-level">
                                    <input type="hidden" name="group_name" class="group_name">
                                    <input type="hidden" name="list_id" value=<?php echo e($item->id); ?>>
                                    <input type="hidden" name="user_id" value=<?php echo e($item->user_id); ?>>
                                     <input type="hidden" name="user_email" value=<?php echo e($item->user->email); ?>>
                                    <input type="hidden" name="user_name" value=<?php echo e($item->user->full_name); ?>>
                                  </form>


                                  


                                  
                                  <form action="<?php echo e(route('wait_list.update',$item->id)); ?>" method="post" id=<?php echo e("update".$item->id); ?>>
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <input type="hidden" name="input-position" class="input-position">
                                    <input type="hidden" name="old_position"  class="old_position" value=<?php echo e($item->position); ?>>
                                  </form>

                                  
                                  <form action="<?php echo e(route('wait_list.destroy',$item->id)); ?>" method="POST" id=<?php echo e("delete".$item->id); ?>>
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                  </form>
                                  <a class="dropdown-item"
                                  href="#"
                                  onclick="showModal(this,'myModal')"
                                    data-user_id=<?php echo e($item->id); ?>

                                    data-user_name=<?php echo e($item->user->full_name); ?>

                                    >Change Position</a>

                                  
                                  <a class="dropdown-item" href="#"
                                  data-user_id=<?php echo e($item->id); ?>

                                  onclick="showModal(this,'remove_user')"
                                  data-user_name=<?php echo e($item->user->full_name); ?>

                                  >Remove User</a>
                              </div>
                          </div>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                  <?php else: ?>
                      <p>There are no users on the waiting list</p>
                  <?php endif; ?>
                    
                <?php endif; ?>
              </div>
            </div>
</div>
    

<div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
              <h5 class="modal-title" id="myModalLabel">Change Postion</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
              </button>
          </div>
          <div class="modal-body">
              <div class="form-group">
                  <label for="position" class="control-label mb-1">Enter New Position for <span class="u-name"></span></label>
                  <input id="position" name="position" type="text" class="form-control" aria-required="true" aria-invalid="false">
              </div>
              <div class="form-group">
                  <div class="col-12">
                      <button type="button" class="btn btn-primary btn-block"  onclick="updatePostion()">Change Position</button>
                  </div>
              </div>
           
          </div>
          <div class="modal-footer">
          </div>

      </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div>

<div id="remove_user" class="modal fade">
	<div class="modal-dialog modal-confirm modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header flex-column">
				<div class="icon-box">
                    <i class="fa fa-times"></i>
				</div>						
				<h4 class="modal-title w-100">Are you sure?</h4>	
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			</div>
			<div class="modal-body">
				<p>Do you really want to remove <strong class="u-name">GROUP NAME</strong> from wait list ? This process cannot be undone.</p>
			</div>
			<div class="modal-footer justify-content-center">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
          <button  class="btn btn-primary" onclick="deleteUser()">Proceed</button>
			</div>
		</div>
	</div>
</div>


<div id="addUser" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
              <h5 class="modal-title" id="myModalLabel">Add <span class="u-name"> </span> to Flower</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
              </button>
          </div>
          <div class="modal-body">
              <div class="form-group">
                  <p >Please choose one to continue </p>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <label class="input-group-text" name="group" for="level">Choose flower</label>
                    </div>
                    <select class="custom-select" id="group-name" name="group-name">
                      <option disabled selected value="">Select One</option>
                      <?php if(count($groups) > 0): ?>
                          <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                          All available flowers are closed
                      <?php endif; ?>
                    </select>
                  </div>
                  <p >Please choose one to continue </p>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <label class="input-group-text" name="level" for="level">Choose level</label>
                    </div>
                    <select class="custom-select" id="level">
                      <option disabled selected value="">Select One</option>
                     
                      <option value="water">Water</option>
                      <option value="earth">Earth</option>
                      <option value="wind">Wind</option>
                      <option value="fire">Fire</option>
                    </select>
                    </div>
              </div>
              <div class="form-group">
                  <div class="col-12">
                      <button type="button" class="btn btn-primary btn-block"  onclick="addUser()">Add User</button>
                  </div>
              </div>
          </div>
          <div class="modal-footer">
          </div>

      </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div>


<div id="generate" class="modal fade">
	<div class="modal-dialog modal-confirm modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header flex-column">
				<h4 class="modal-title w-100">Are you sure?</h4>	
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			</div>
			<div class="modal-body">
				<p>You about to create a new flower from wait list, are sure you want to proceed ?</p>
			</div>
			<div class="modal-footer justify-content-center">
                <form action="<?php echo e(route('generate')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button  class="btn btn-primary" type="submit">Proceed</button>
             </form>
			
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
    <script>
         let user_id;
        let user_name;
        function showModal(element,modalName){
             user_id = element.dataset.user_id;
             user_name = element.dataset.user_name;
            let option = element.dataset.request;
            let request  = element.textContent.split(' ')[0].toLowerCase();
            $('#request-option').text(request);
            $('.u-name').text(" "+user_name);
            $('.input-status').val(option);
            $(`#${modalName}`).modal('show');
        }

        function generateModal(){
          $(`#generate`).modal('show');
        }

        function updatePostion(){
            let position = $("#position").val();
            $('.input-position').val(position);
            $(`#update${user_id}`).submit();
        }

        function deleteUser(){
            $(`#delete${user_id}`).submit();
            
        }

        function addUser(){
          let level = $("#level").val();
          let group = $('#group-name').val();
          $('.user-level').val(level);
          $('.group_name').val(group);
          $(`#add${user_id}`).submit();
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sou-sou\sou-sou\resources\views/dashboard/wait_list.blade.php ENDPATH**/ ?>