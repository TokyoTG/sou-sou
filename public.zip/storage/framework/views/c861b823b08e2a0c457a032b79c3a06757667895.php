

<?php $__env->startSection('title'); ?>
<title>YBA | Forgot Password </title> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="row justify-content-center">

    <div class="col-xl-10 col-lg-12 col-md-9">

      <div class="card o-hidden border-0 shadow-lg my-5">
        <div class="card-body p-0">
          <!-- Nested Row within Card Body -->
          <div class="row">
            <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
            <div class="col-lg-6">
              <div class="p-5">
                <div class="text-center">
                  <h1 class="h4 text-gray-900 mb-4">Forgot Password</h1>
                  <?php if(Session::has('message')): ?>
                  <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>">
                      <?php echo e(Session::get('message')); ?></p>
                <?php endif; ?>
                  <p>Please enter the email associated with your account</p>
                </div>
              <form class="user" method="POST" action="<?php echo e(route('forgot')); ?>">
                  <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <input type="email" class="form-control form-control-user" name="email" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Enter Email Address...">
                  </div>
                  <button href="#" class="btn btn-primary btn-user btn-block" type="submit">
                    Submit
                  </button>
                  <hr>
                </form>
                <div class="text-center">
                  Remember your password ? <a class="medium" href="<?php echo e(route('login')); ?>">login</a>
                </div>
                <div class="text-center">
                  Don't have an account ?<a class="medium" href="<?php echo e(route('register')); ?>"> Create an Account!</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>

  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.auth_base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sou-sou\sou-sou\resources\views/forgot.blade.php ENDPATH**/ ?>