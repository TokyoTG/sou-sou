 <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active links">
                    <a href="<?php echo e(route('dashboard.index')); ?>"><i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <li class="menu-title">Menu</li><!-- /.menu-title -->
                    <li class="links">
                        <a href="<?php echo e(route('dashboard.users')); ?>"> <i class="menu-icon fa fa-users"></i>Users</a>
                    </li>
                     <li class="links">
                        <a href="<?php echo e(route('dashboard.groups')); ?>"> <i class="menu-icon fa fa-folder"></i>Groups</a>
                    </li>
                     <li class="links">
                        <a href="<?php echo e(route('dashboard.wait_list')); ?>"> <i class="menu-icon fa fa-list-alt"></i>Wait List</a>
                    </li>
                    <li class="links">
                        <a href="<?php echo e(route('dashboard.complaints')); ?>"> <i class="menu-icon fa fa-list-alt"></i>Complaints</a>
                    </li>
                    <li class="links">
                        <a href="<?php echo e(route('dashboard.settings')); ?>"> <i class="menu-icon fa fa-cogs"></i>Settings</a>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav><?php /**PATH C:\xampp\htdocs\sou-sou\sou-sou\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>