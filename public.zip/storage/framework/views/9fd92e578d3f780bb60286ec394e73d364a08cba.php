<?php

   function is_admin(){
        return Cookie::get('role') !== null && Cookie::get('role') == "admin";
    }

    function is_member(){
        return Cookie::get('role') !== null && Cookie::get('role') == "member";
    }
?><?php /**PATH C:\xampp\htdocs\sou-sou\sou-sou\resources\views/partials/auth_check.blade.php ENDPATH**/ ?>