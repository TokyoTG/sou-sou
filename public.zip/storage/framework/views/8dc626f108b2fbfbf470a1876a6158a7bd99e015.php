

<?php $__env->startSection('title'); ?>
<title>YBA | Register </title> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="card o-hidden border-0 shadow-lg my-5">
    <div class="card-body p-0">
      <!-- Nested Row within Card Body -->
      <div class="row">
        <div class="col-lg-5 d-none d-lg-block bg-register-image"></div>
        <div class="col-lg-7">
          <div class="p-5">
            <div class="text-center">
              <h1 class="h4 text-gray-900 mb-4">Create an Account!</h1>
            </div>
                   <?php if(Session::has('message')): ?>
                                        <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>">
                                            <?php echo e(Session::get('message')); ?></p>
                                        <?php endif; ?>
          <form class="user" action="<?php echo e(route('signup')); ?>" method="POST">
            <?php echo csrf_field(); ?>
              <div class="form-group row">
                <div class="col-sm-6 mb-3 mb-sm-0">
                  <input type="text" class="form-control form-control-user" id="exampleFirstName" name="first_name" placeholder="First Name">
                </div>
                <div class="col-sm-6">
                  <input type="text" class="form-control form-control-user" id="exampleLastName" name="last_name" placeholder="Last Name">
                </div>
              </div>
              <div class="form-group row">
                <div class="col-sm-6 mb-3 mb-sm-0">
                   <input type="email" class="form-control form-control-user" id="exampleInputEmail" name="email" placeholder="Email Address">
                </div>
                <div class="col-sm-6">
                  <input type="tel" class="form-control form-control-user" id="exampleLastName" name="phone_number" placeholder="Phone Number">
                </div>
              </div>
              <div class="form-group row">
                <div class="col-sm-6 mb-3 mb-sm-0">
                  <input type="password" class="form-control form-control-user" id="exampleInputPassword" name="password" placeholder="Password">
                </div>
                <div class="col-sm-6">
                  <input type="password" class="form-control form-control-user" id="exampleRepeatPassword" name="password_confirmation" placeholder="Repeat Password">
                </div>
              </div>
                  <button class="btn btn-primary btn-user btn-block" type="submit">
                    Register
                  </button>
            </form>
            <hr>

            <div class="text-center">
           Already have an account ? <a class="medium" href="<?php echo e(route('login')); ?>">Login</a>
            </div>
            <div class="text-center">
                <a class="medium" href="<?php echo e(route('forgot')); ?>">Forgot Password?</a>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.auth_base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sou-sou\sou-sou\resources\views/register.blade.php ENDPATH**/ ?>