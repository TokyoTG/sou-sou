<div>
     <h1>Forgot Password Request</h1>   
</div>

<?php /**PATH C:\xampp\htdocs\sou-sou\sou-sou\resources\views/emails/forgot.blade.php ENDPATH**/ ?>