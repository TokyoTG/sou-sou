

<?php $__env->startSection('title'); ?>
<title>YBA | Wait List </title> 
    <h4>Wait List</h4>
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/assets/css/mystyle.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('newBtn'); ?>
   <?php if(Cookie::get('role') !== null && Cookie::get('role') == "admin"): ?>
 <button class="d-sm-inline-block btn  btn-primary shadow-sm" data-toggle="modal" data-target="#myModal"> New
     <i class="fa fa-plus my-float"></i></button>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>

  <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Wait List</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                
                    <?php if(isset($user_list)): ?>
                        <?php if(count($user_list) > 0): ?>
                        <?php
                            $counter = 0;

                        ?>
                        <table id="bootstrap-data-table" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Duration on List</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
    
                                $now = time(); 
                                $your_date = strtotime($list->created_at);
                                $datediff = round(($now - $your_date) / 86400);   
                                if($datediff < 1){
                                    $datediff = round(($now - $your_date) / 3600);
                                    $join_date = $datediff."Hours ago";
                                    if($datediff > 0){
                                        if($datediff > 1){
                                            $join_date = $datediff." Hours ago";
                                        }else{
                                            $join_date = $datediff." Hour ago";
                                        }
                                    }else{
                                        $datediff = round(($now - $your_date) / 60);
                                       
                                        if($datediff > 1){
                                         $join_date = $datediff." Minutes ago";
                                        }else{
                                            $join_date = $datediff." Minute ago";
                                        }
                                    }
                                  
                                }elseif($datediff >= 2) {
                                      $join_date = $datediff." Days ago";
                                }else{
                                        $join_date = "Yestarday";
                                      }
                                ?>
                                    <tr>
                                    <td><?php echo e(++$counter); ?></td>
                                    <td><?php echo e("Joined ".$join_date); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                        You are not in the waiting list
                        <?php endif; ?>
                      
                <?php endif; ?>
    
           </div>
            </div>
</div>


<div id="myModal" class="modal fade">
	<div class="modal-dialog modal-confirm modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header flex-column">
				<h4 class="modal-title w-100">Are you sure?</h4>	
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			</div>
			<div class="modal-body">
				<p>You about to join <span ><strong id="g-name">GROUP NAME</strong> flower</span> , are sure you want to proceed ?</p>
			</div>
			<div class="modal-footer justify-content-center">
                <form action="<?php echo e(route('wait_list.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="group_id" id="input-group">
                    <input type="hidden" name="group_name" id="input-name">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button  class="btn btn-primary" type="submit">Proceed</button>
             </form>
			
			</div>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
    <script>
        function showModal(element){
            let group_id = element.dataset.group_id;
            let group_name = element.dataset.group_name;
            $('#g-name').text(group_name);
            $('#input-group').val(group_id);
            $('#input-name').val(group_name);
            $('#myModal').modal('show');
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sou-sou\sou-sou\resources\views/dashboard/user_list.blade.php ENDPATH**/ ?>