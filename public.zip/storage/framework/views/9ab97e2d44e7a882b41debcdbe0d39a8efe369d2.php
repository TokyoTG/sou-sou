<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('dashboard/assets/apple-touch-icon.png')); ?>">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('dashboard/assets/favicon-32x32.png')); ?>">
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('dashboard/assets/favicon-16x16.png')); ?>">
<link rel="manifest" href="<?php echo e(asset('dashboard/assets/site.webmanifest')); ?>">
  <meta name="author" content="">

  <?php echo $__env->yieldContent('title'); ?>

  <!-- Custom fonts for this template-->
  <link href="<?php echo e(asset('dashboard/assets/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="<?php echo e(asset('dashboard/assets/css/sb-admin-2.min.css')); ?>" rel="stylesheet">

</head>


<style>
  .bg-login-image,.bg-register-image,.bg-password-image {
  background: url("<?php echo e(asset('dashboard/assets/img/YBA_Logo.png')); ?>");
  background-position: center;
  background-size: cover;
}

#logo{
  height: 50px;
  margin-top:10px;
  display: inline-block;
  width: 100px;
}

#logo img{
  width: 100%;
  border-radius: 10px;
  background: white;
  height: 100%;
}
</style>

<body class="bg-gradient-primary">

  <div class="container">
  <a href="<?php echo e(route('welcome')); ?>"  id="logo">
      <img src="<?php echo e(asset('dashboard/assets/img/YBA_Logo.png')); ?>" alt="logo" >
      </a>
   
        <?php echo $__env->yieldContent('content'); ?>




  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo e(asset('dashboard/assets/vendor/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('dashboard/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

  <!-- Core plugin JavaScript-->
  <script src="<?php echo e(asset('dashboard/assets/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

  <!-- Custom scripts for all pages-->
  <script src="<?php echo e(asset('dashboard/assets/js/sb-admin-2.min.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\sou-sou\sou-sou\resources\views/layout/auth_base.blade.php ENDPATH**/ ?>