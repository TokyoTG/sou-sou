

<?php $__env->startSection('title'); ?>
<title>YBA | Method</title> 
    <h4>Method</h4>
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/assets/css/mystyle.css')); ?>">
    <a href="<?php echo e(route('gift_methods.index')); ?>" class="btn btn-primary">Back</a>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contents'); ?>
<?php if(Session::has('message')): ?>
<p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>">
    <?php echo e(Session::get('message')); ?></p>
<?php endif; ?>
  <div class="content">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title"><?php echo e($method->platform); ?></strong>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                               
                                   <h5><?php echo e($method->platform); ?></h5>
                                   <p> Details: <br> <?php echo e($method->details); ?></p>
                                    <p>Contact Details: <br> <?php echo e($method->contact); ?></p>
                                </div>
                              
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- .animated -->
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sou-sou\sou-sou\resources\views/dashboard/payment_method/show.blade.php ENDPATH**/ ?>