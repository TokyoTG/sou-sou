
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('dashboard/assets/apple-touch-icon.png')); ?>">
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('dashboard/assets/favicon-32x32.png')); ?>">
  <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('dashboard/assets/favicon-16x16.png')); ?>">
  <link rel="manifest" href="<?php echo e(asset('dashboard/assets/site.webmanifest')); ?>">
  <meta name="author" content="Toyeeb Ganiu 07069732084">

  <?php echo $__env->yieldContent('title_page'); ?>

  <!-- Custom fonts for this template-->
  <link href="<?php echo e(asset('dashboard/assets/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="<?php echo e(asset('dashboard/assets/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
  <style>
    .nav-tabs .nav-link.active{
      border-left: 3px solid #4e73df;
    }

    .fa-eye{
      font-size: 1.2em;
    }
    td{
      text-align: center;
    }

    a:hover{
      text-decoration: none;
    }
    .sidebar-brand-text{
      text-transform: capitalize;
    }
    /* .container-fluid{
      height: 500px;
      overflow: auto;
    } */
    
  </style>

</head>

<?php

   function is_admins(){
        return Cookie::get('role') !== null && Cookie::get('role') == "admin";
    }

    function is_members(){
        return Cookie::get('role') !== null && Cookie::get('role') == "member";
    }
?>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('dashboard.index')); ?>">
        <div class="sidebar-brand-icon rotate-n-0">
          <i class="fas fa-user-circle"></i>
        </div>
        <div class="sidebar-brand-text mx-2">
          <?php if(is_admins()): ?>
            Super Admin
          <?php endif; ?>
          <?php if(is_members() && Cookie::get('full_name') !== null): ?>
              <?php echo e(Cookie::get('full_name')); ?> 
          <?php endif; ?>
        </div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('dashboard.index')); ?>">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Menu
      </div>

   

      <?php if(is_admins()): ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
            <i class="fa-fw fa fa-users"></i>
            <span>Users</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('wait_list.index')); ?>">
           <i class="menu-icon fa fa-list-alt"></i>
            <span>Wait List</span></a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('flowers.index')); ?>">
           <i class="fa-fw fa fa-folder"></i>
            <span>Flowers</span>
          </a>
        </li>
      
      <?php endif; ?>


    
    
      <?php if(is_members()): ?>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('user_list')); ?>">
            <i class="fa-fw fa fa-user-plus"></i>
            <span>Wait List</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('tasks.index')); ?>">
           <i class="menu-icon fa fa-tasks"></i>
            <span>Tasks</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('flowers.index')); ?>">
           <i class="fa-fw fa fa-folder"></i>
            <span>My Flowers</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('payments')); ?>">
           <i class="menu-icon fa fa-money-check"></i>
            <span>Verify Gifts</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('gift_methods.index')); ?>">
            <i class="fa-fw fa fa-money-check-alt"></i>
              <span>Gift Methods</span>
          </a>
        </li>
      <?php endif; ?>
      <!-- Nav Item - Charts -->
      <!-- Nav Item - Tables -->
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('users.edit',Cookie::get('id'))); ?>">
          <i class="menu-icon fa fa-cogs"></i>
          <span>Settings</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>
          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>
            <?php
                $tasks = Session::get('tasks') ? Session::get('tasks') : array();
                // var_dump($tasks) ;
                // die();
            ?>

            <!-- Nav Item - Alerts -->
            <li class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-bell fa-fw"></i>
                <!-- Counter - Alerts -->
         
                   <?php if(count($tasks) > 0): ?>
                  <span class="badge badge-danger badge-counter"><?php echo e(count($tasks)); ?></span>
          
                  <?php endif; ?>
              </a>
              <!-- Dropdown - Alerts -->
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
                <h6 class="dropdown-header">
                  New Tasks
                </h6>
                <?php if(isset($tasks)): ?>
                  <?php if(count($tasks) > 0): ?>
                      <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('tasks.show',$item->id)); ?>">
                        <div class="mr-3">
                          <div class="icon-circle bg-success">
                            <i class="fas fa-donate text-white"></i>
                          </div>
                        </div>
                        <div>
                          <div class="small text-gray-500"><?php echo e(date("D d M Y h:i:sa",strtotime($item->created_at))); ?></div>
                          <?php echo e($item->title); ?>

                        </div>
                      </a>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                  
                  <?php endif; ?>
                    
                <?php endif; ?>
                
                    <a class="dropdown-item text-center small text-gray-500" href="<?php echo e(route('tasks.index')); ?>">Show All Tasks</a>
              </div>
            </li>

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                <?php if(is_admins()): ?>
                  Super Admin
                <?php elseif(is_members() && Cookie::get('full_name') !== null): ?>
                  <?php echo e(Cookie::get('full_name')); ?>  
                <?php endif; ?>
              </span>
              <div class="sidebar-brand-icon rotate-n-0">
                <i class="fas fa-user-circle"></i>
              </div>
                
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="<?php echo e(route('users.edit',Cookie::get('id'))); ?>">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Settings
                </a>
                <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
          <?php echo $__env->yieldContent('title'); ?>
          <?php echo $__env->yieldContent('newBtn'); ?>
          </div>   
           <?php echo $__env->yieldContent('contents'); ?>
          </div>
        <!-- /.container-fluid -->
      
      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; YBA 2020</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>


  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo e(asset('dashboard/assets/vendor/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('dashboard/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

  <!-- Core plugin JavaScript-->
  <script src="<?php echo e(asset('dashboard/assets/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

  <!-- Custom scripts for all pages-->
  <script src="<?php echo e(asset('dashboard/assets/js/sb-admin-2.min.js')); ?>"></script>
  <?php echo $__env->yieldContent('custom_js'); ?>
  <script>
    let links = [...document.getElementsByClassName('nav-item')];
   var loc = window.location.href;
      $(document).ready(()=>{
        links.forEach(link=>{
        if(link.firstElementChild.getAttribute('href')  == loc){
          link.classList.add('active');

        }
      })
      })
      setTimeout(function(){
        $('.alert').hide();
      },5000)
  </script>
</body>

</html>

<body><?php /**PATH C:\xampp\htdocs\sou-sou\sou-sou\resources\views/layout/base.blade.php ENDPATH**/ ?>