<div>
     <h1>Sou Sou Account Forgot Password Request</h1>   
     <p>Hello, a password request for an account with Sou Sou was sent</p>
</div>

